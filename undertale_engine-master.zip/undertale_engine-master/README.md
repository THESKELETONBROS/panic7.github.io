# UNDERTALE Engine
## PROJECT PAUSED BUT NOT ABORTED
**Due to the massive pressure, this project has been paused for now, but it will not be aborted until it is finished.**
